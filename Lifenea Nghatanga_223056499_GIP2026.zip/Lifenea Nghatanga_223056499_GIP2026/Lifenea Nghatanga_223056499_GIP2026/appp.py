from flask import Flask, request
import pandas as pd
import folium

app = Flask(__name__)

# LOAD DATA
data = pd.read_csv("placess.csv", sep=";")
data.columns = data.columns.str.strip().str.lower()

# CLEAN RISK
data["risk"] = data["risk"].astype(str).str.strip().str.upper()

# FIND NEAREST POINT
def find_nearest(lat, lon):

    d = (
        (data["latitude"] - lat) ** 2 +
        (data["longitude"] - lon) ** 2
    )

    return data.loc[d.idxmin()]

# COLOR FUNCTION
def get_color(risk):

    return {

        "HIGH": "red",
        "MEDIUM": "orange",
        "LOW": "yellow",
        "SAFE": "green"

    }.get(risk, "gray")

# RISK EMOJI
def get_risk_emoji(risk):

    if risk == "HIGH":
        return "🔴"

    elif risk == "MEDIUM":
        return "🟠"

    elif risk == "LOW":
        return "🟡"

    else:
        return "🟢"

# HOME PAGE
@app.route("/")
def home():

    return """

    <html>

    <head>

        <title>Flood Risk App</title>

        <style>

            body {

                font-family: Arial;
                background: #a8d8ff;
                text-align: center;
                padding-top: 60px;
                margin: 0;

            }

            .box {

                background: white;
                padding: 35px;
                margin: auto;
                width: 380px;
                border-radius: 15px;
                box-shadow:
                0 6px 18px rgba(0,0,0,0.2);

            }

            input {

                margin: 10px;
                padding: 12px;
                width: 85%;
                border-radius: 6px;
                border: 1px solid #ccc;
                font-size: 14px;

            }

            button {

                padding: 12px 22px;
                margin: 5px;
                background: #2ecc71;
                color: white;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 14px;

            }

            button:hover {

                opacity: 0.9;

            }

            .locbtn {

                background: #3498db;

            }

            h2 {

                margin-bottom: 20px;
                color: #2c3e50;

            }

            p {

                color: #555;
                line-height: 1.6;

            }

        </style>

        <script>

            function getLocation() {

                if (navigator.geolocation) {

                    navigator.geolocation.getCurrentPosition(

                        function(position) {

                            document.getElementById("lat").value =
                            position.coords.latitude;

                            document.getElementById("lon").value =
                            position.coords.longitude;
                        },

                        function(error) {

                            alert(
                            "Location error: "
                            + error.message
                            );

                        },

                        {
                            enableHighAccuracy: true,
                            timeout: 10000,
                            maximumAge: 0
                        }
                    );

                } else {

                    alert(
                    "Geolocation not supported."
                    );

                }
            }

        </script>

    </head>

    <body>

        <div class="box">

            <h2>🌊 Flood Risk Checker</h2>

            <p>

            Use current location (approximate)
            OR enter exact coordinates in Namibia

            </p>

            <button
            class="locbtn"
            onclick="getLocation()">

            📍 Use My Location

            </button>

            <form action="/check">

                <input
                id="lat"
                name="lat"
                placeholder="Latitude"
                required>

                <br>

                <input
                id="lon"
                name="lon"
                placeholder="Longitude"
                required>

                <br>

                <button type="submit">

                Check Risk

                </button>

            </form>

        </div>

    </body>

    </html>

    """

# CHECK ROUTE
@app.route("/check")
def check():

    lat = float(request.args.get("lat"))
    lon = float(request.args.get("lon"))

    nearest = find_nearest(lat, lon)

    risk = nearest["risk"]

    place = str(
        nearest.get("name", "Nearest Area")
    )

    # RIVER SYSTEMS

    if lat > -18.2 and lon > 23:

        river = "Zambezi River"

    elif lat > -19.5 and lon > 18:

        river = "Okavango River"

    elif lat > -19 and lon < 15:

        river = "Kunene River"

    elif lat > -21:

        river = "Cuvelai System"

    elif lat < -26:

        river = "Orange River"

    else:

        river = "Ephemeral Rivers"

    # HISTORY

    if risk == "HIGH":

        history = """
        Highly flood-prone area near major water systems.
        """

    elif risk == "MEDIUM":

        history = """
        Moderate flood risk during heavy rainfall events.
        """

    elif risk == "LOW":

        history = """
        Low flood risk under normal conditions.
        """

    else:

        history = """
        Generally safe area with minimal flood risk.
        """

    # CREATE MAP

    m = folium.Map(

        location=[-22.5, 17],
        zoom_start=6,
        tiles="CartoDB Voyager"

    )

    # LEGEND

    legend_html = """

    <div style="
    position: fixed;
    top: 45%;
    left: 15px;
    transform: translateY(-50%);
    width: 220px;
    background-color: white;
    border-radius: 14px;
    padding: 18px;
    z-index: 999999;
    font-size: 18px;
    font-family: Arial;
    font-weight: bold;
    box-shadow: 0 0 18px rgba(0,0,0,0.4);
    border: 3px solid #3498db;
    ">

    <div style="
    text-align:center;
    font-size:20px;
    margin-bottom:15px;
    color:#2c3e50;
    ">

    Legend

    </div>

    <div style="margin-bottom:10px;">
    🔴 High Risk
    </div>

    <div style="margin-bottom:10px;">
    🟠 Medium Risk
    </div>

    <div style="margin-bottom:10px;">
    🟡 Low Risk
    </div>

    <div>
    🟢 Safe
    </div>

    </div>

    """

    m.get_root().html.add_child(
        folium.Element(legend_html)
    )

    # POPUP

    popup_html = f"""

    <div style='
    font-family: Arial;
    width:320px;
    padding:5px;
    font-size:12px;
    line-height:1.5;
    '>

    <h3 style="
    margin-bottom:10px;
    color:#2c3e50;
    font-size:20px;
    ">

    {get_risk_emoji(risk)}
    {place}

    </h3>

    <b>⚠️ Risk Level:</b> {risk}<br><br>

    <b>🌊 Nearby River System:</b> 
     {river}<br><br>

    <b>🗺️ History:</b> 
    {history}

    </div>

    """

    # RESULT MARKER

    folium.CircleMarker(

        location=[
            nearest["latitude"],
            nearest["longitude"]
        ],

        radius=8,

        color=get_color(risk),

        fill=True,

        fill_color=get_color(risk),

        fill_opacity=0.9,

        popup=folium.Popup(
            popup_html,
            max_width=400
        )

    ).add_to(m)

    return f"""

    <html>

    <head>

    <style>

    body {{

        margin:0;

        background:
        linear-gradient(
        to right,
        #dfe9f3,
        #ffffff
        );

    }}

    iframe {{

        width:100%;
        height:100vh;
        border:none;

    }}

    </style>

    </head>

    <body>

    {m._repr_html_()}

    </body>

    </html>

    """

if __name__ == "__main__":
    app.run(debug=True)